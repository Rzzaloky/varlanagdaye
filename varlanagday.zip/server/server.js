const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

let votes = {
  home: 0,
  draw: 0,
  away: 0,
};

app.post("/api/vote", (req, res) => {
  const { homeTeam, awayTeam, choice } = req.body;

  if (!homeTeam || !awayTeam || !choice) {
    return res.status(400).json({ error: "Eksik veri." });
  }

  votes[choice] += 1;

  return res.status(200).json({
    message: "Oyunuz başarıyla kaydedildi.",
    votes,
  });
});

app.post("/api/predict", (req, res) => {
  const { homeTeam, awayTeam } = req.body;

  const prediction = {
    homeWin: Math.random(),
    draw: Math.random(),
    awayWin: Math.random(),
  };

  return res.status(200).json({ prediction });
});

app.listen(port, () => {
  console.log(`Sunucu çalışıyor: http://localhost:${port}`);
});