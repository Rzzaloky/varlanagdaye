import React from 'react';
import { usePrediction } from '../../context/PredictionContext';
import TeamSelection from './TeamSelection';
import PredictionResult from './PredictionResult';
import toast from 'react-hot-toast';
import { ArrowRight } from 'lucide-react';

const PredictionForm: React.FC = () => {
  const { 
    selectedHomeTeam, 
    selectedAwayTeam, 
    predictMatch, 
    loading, 
    error 
  } = usePrediction();
  
  const [prediction, setPrediction] = React.useState<any>(null);
  const [isSubmitted, setIsSubmitted] = React.useState(false);

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedHomeTeam || !selectedAwayTeam) {
      toast.error('Lütfen her iki takımı da seçin');
      return;
    }
    
    if (selectedHomeTeam.id === selectedAwayTeam.id) {
      toast.error('Aynı takımı iki kez seçemezsiniz');
      return;
    }
    
    const result = await predictMatch();
    if (result) {
      setPrediction(result);
      setIsSubmitted(true);
    }
  };

  const handleReset = () => {
    setPrediction(null);
    setIsSubmitted(false);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {!isSubmitted ? (
        <>
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-secondary mb-2">
              Maç Tahmin Aracı
            </h2>
            <p className="text-gray-600">
              Karşılaşacak takımları seçin ve tahmininizi görün
            </p>
          </div>
          
          <form onSubmit={handlePredict} className="bg-white rounded-xl shadow-md p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <TeamSelection isHome={true} />
              <TeamSelection isHome={false} />
            </div>
            
            <div className="flex items-center justify-center my-6">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <ArrowRight className="text-primary" size={20} />
              </div>
            </div>
            
            <div className="mt-6">
              <button
                type="submit"
                className="btn btn-primary w-full py-3 text-lg"
                disabled={loading}
              >
                {loading ? 'Tahmin Ediliyor...' : 'Tahmin Et'}
              </button>
            </div>
            
            {error && (
              <div className="mt-4 p-3 bg-error/10 text-error rounded-md">
                {error}
              </div>
            )}
          </form>
        </>
      ) : (
        <>
          <PredictionResult prediction={prediction} />
          <div className="mt-6 text-center">
            <button
              onClick={handleReset}
              className="btn btn-outline"
            >
              Yeni Tahmin Yap
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default PredictionForm;