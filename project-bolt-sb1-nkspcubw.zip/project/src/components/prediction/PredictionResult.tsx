import React from 'react';
import { MatchPrediction } from '../../types';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Award, TrendingUp, Calendar } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';

ChartJS.register(ArcElement, Tooltip, Legend);

interface PredictionResultProps {
  prediction: MatchPrediction;
}

const PredictionResult: React.FC<PredictionResultProps> = ({ prediction }) => {
  const { homeTeam, awayTeam, homeWinProbability, drawProbability, awayWinProbability, estimatedHomeGoals, estimatedAwayGoals } = prediction;
  
  const chartData = {
    labels: [
      `${homeTeam.name} Kazanır`,
      'Beraberlik',
      `${awayTeam.name} Kazanır`
    ],
    datasets: [
      {
        data: [homeWinProbability, drawProbability, awayWinProbability],
        backgroundColor: ['#E30A17', '#FDB913', '#041E42'],
        borderColor: ['rgba(0, 0, 0, 0)'],
        borderWidth: 0,
      },
    ],
  };
  
  const chartOptions = {
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          font: {
            size: 14
          }
        }
      }
    },
    cutout: '60%'
  };

  const mostLikelyOutcome = () => {
    const max = Math.max(homeWinProbability, drawProbability, awayWinProbability);
    if (max === homeWinProbability) return `${homeTeam.name} Kazanır`;
    if (max === drawProbability) return 'Beraberlik';
    return `${awayTeam.name} Kazanır`;
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden animate-slide-in">
      <div className="p-6 bg-secondary text-white">
        <h3 className="text-xl md:text-2xl font-bold text-center">
          Maç Tahmini: {homeTeam.name} - {awayTeam.name}
        </h3>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left column - Chart */}
          <div className="flex flex-col items-center justify-center">
            <h4 className="text-lg font-semibold mb-4 text-center">Kazanma Olasılıkları</h4>
            <div className="w-full max-w-xs relative">
              <Doughnut data={chartData} options={chartOptions} />
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="text-3xl font-bold text-primary">
                  {Math.max(homeWinProbability, drawProbability, awayWinProbability)}%
                </span>
                <span className="text-xs text-gray-500">En yüksek olasılık</span>
              </div>
            </div>
          </div>
          
          {/* Right column - Stats */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Tahmin Detayları</h4>
            
            <div className="space-y-4">
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Award className="text-primary mr-3" size={24} />
                <div>
                  <p className="text-sm text-gray-500">En Olası Sonuç</p>
                  <p className="font-semibold">{mostLikelyOutcome()}</p>
                </div>
              </div>
              
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <TrendingUp className="text-primary mr-3" size={24} />
                <div>
                  <p className="text-sm text-gray-500">Tahmini Skor</p>
                  <p className="font-semibold">{Math.round(estimatedHomeGoals)} - {Math.round(estimatedAwayGoals)}</p>
                </div>
              </div>
              
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Calendar className="text-primary mr-3" size={24} />
                <div>
                  <p className="text-sm text-gray-500">Tahmin Tarihi</p>
                  <p className="font-semibold">
                    {formatDistanceToNow(new Date(prediction.created), { 
                      addSuffix: true,
                      locale: tr 
                    })}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="text-lg font-semibold mb-2">Takım Formları</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex items-center mb-2">
                    <img 
                      src={homeTeam.logo}
                      alt={homeTeam.name}
                      className="w-6 h-6 mr-2"
                    />
                    <span className="font-medium">{homeTeam.name}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-primary h-2.5 rounded-full" 
                      style={{ width: `${homeTeam.form * 10}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center mb-2">
                    <img 
                      src={awayTeam.logo}
                      alt={awayTeam.name}
                      className="w-6 h-6 mr-2"
                    />
                    <span className="font-medium">{awayTeam.name}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-secondary h-2.5 rounded-full" 
                      style={{ width: `${awayTeam.form * 10}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 p-4 bg-primary/10 rounded-lg border border-primary/20">
          <p className="text-gray-700 text-sm">
            <strong>Not:</strong> Bu tahmin, takımların son 5 maçtaki performansı, ev sahibi avantajı, gol ortalamaları ve diğer istatistiksel veriler kullanılarak oluşturulmuştur. Gerçek sonuçlar değişiklik gösterebilir.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PredictionResult;