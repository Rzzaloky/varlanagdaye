import React from 'react';
import { usePrediction } from '../../context/PredictionContext';
import type { Team } from '../../types';

interface TeamSelectionProps {
  isHome: boolean;
}

const TeamSelection: React.FC<TeamSelectionProps> = ({ isHome }) => {
  const { 
    teams,
    selectedHomeTeam,
    selectedAwayTeam,
    setSelectedHomeTeam,
    setSelectedAwayTeam
  } = usePrediction();

  // Group teams by league
  const teamsByLeague = teams.reduce((acc, team) => {
    if (!acc[team.league]) {
      acc[team.league] = [];
    }
    acc[team.league].push(team);
    return acc;
  }, {} as Record<string, Team[]>);

  const handleTeamChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const teamId = event.target.value;
    const team = teams.find(t => t.id === teamId) || null;
    
    if (isHome) {
      setSelectedHomeTeam(team);
    } else {
      setSelectedAwayTeam(team);
    }
  };

  const selectedTeam = isHome ? selectedHomeTeam : selectedAwayTeam;

  return (
    <div className="w-full">
      <label 
        htmlFor={isHome ? "homeTeam" : "awayTeam"}
        className="block text-gray-700 text-sm font-medium mb-2"
      >
        {isHome ? "Ev Sahibi Takım" : "Deplasman Takımı"}
      </label>
      <div className="relative">
        <select
          id={isHome ? "homeTeam" : "awayTeam"}
          value={selectedTeam?.id || ""}
          onChange={handleTeamChange}
          className="select appearance-none pr-10"
        >
          <option value="">Takım Seçin</option>
          {Object.entries(teamsByLeague).map(([league, leagueTeams]) => (
            <optgroup key={league} label={league}>
              {leagueTeams.map(team => (
                <option key={team.id} value={team.id}>
                  {team.name}
                </option>
              ))}
            </optgroup>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
          <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
            <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
          </svg>
        </div>
      </div>
      
      {/* Selected team card */}
      {selectedTeam && (
        <div className="mt-4 flex items-center p-3 bg-gray-50 rounded-lg border border-gray-200">
          <img 
            src={selectedTeam.logo} 
            alt={selectedTeam.name} 
            className="w-10 h-10 object-contain mr-3" 
          />
          <div>
            <h4 className="font-medium text-gray-900">{selectedTeam.name}</h4>
            <span className="text-xs text-gray-500">{selectedTeam.league}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamSelection;