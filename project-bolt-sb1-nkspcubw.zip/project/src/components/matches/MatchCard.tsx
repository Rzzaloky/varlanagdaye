import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';
import { ArrowRight, Clock } from 'lucide-react';
import type { Match } from '../../types';

interface MatchCardProps {
  match: Match;
}

const MatchCard: React.FC<MatchCardProps> = ({ match }) => {
  const { id, homeTeam, awayTeam, date, league, stadium } = match;
  
  // Format date
  const matchDate = new Date(date);
  const formattedDate = matchDate.toLocaleDateString('tr-TR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
  
  const formattedTime = matchDate.toLocaleTimeString('tr-TR', {
    hour: '2-digit',
    minute: '2-digit'
  });
  
  const timeFromNow = formatDistanceToNow(matchDate, { 
    addSuffix: true,
    locale: tr
  });
  
  return (
    <Link 
      to={`/mac/${id}`}
      className="block card hover:shadow-lg transition-shadow duration-300"
    >
      <div className="bg-secondary text-white p-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <span className="bg-white text-secondary text-xs rounded-full px-2 py-0.5">
            {league}
          </span>
        </div>
        <div className="flex items-center text-xs text-gray-200">
          <Clock size={12} className="mr-1" />
          {timeFromNow}
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3 flex-1">
            <img 
              src={homeTeam.logo} 
              alt={homeTeam.name}
              className="w-12 h-12 object-contain"
            />
            <span className="font-semibold">{homeTeam.name}</span>
          </div>
          
          <div className="px-3">
            <div className="text-xs text-gray-500 mb-1 text-center">VS</div>
            <ArrowRight className="text-primary" size={20} />
          </div>
          
          <div className="flex items-center space-x-3 flex-1 justify-end">
            <span className="font-semibold">{awayTeam.name}</span>
            <img 
              src={awayTeam.logo} 
              alt={awayTeam.name}
              className="w-12 h-12 object-contain"
            />
          </div>
        </div>
        
        <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between items-center text-sm text-gray-500">
          <div>
            {formattedDate}, {formattedTime}
          </div>
          <div>
            {stadium}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default MatchCard;