import React from 'react';
import { usePrediction } from '../../context/PredictionContext';
import MatchCard from './MatchCard';
import type { League } from '../../types';

interface MatchesListProps {
  league?: League;
  limit?: number;
}

const MatchesList: React.FC<MatchesListProps> = ({ league, limit }) => {
  const { matches } = usePrediction();
  
  // Filter matches by league if specified
  const filteredMatches = league 
    ? matches.filter(match => match.league === league)
    : matches;
  
  // Limit the number of matches if specified
  const limitedMatches = limit 
    ? filteredMatches.slice(0, limit)
    : filteredMatches;
  
  if (limitedMatches.length === 0) {
    return (
      <div className="bg-gray-50 rounded-lg p-6 text-center">
        <p className="text-gray-500">Bu ligde yaklaşan maç bulunmuyor.</p>
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {limitedMatches.map(match => (
        <MatchCard key={match.id} match={match} />
      ))}
    </div>
  );
};

export default MatchesList;