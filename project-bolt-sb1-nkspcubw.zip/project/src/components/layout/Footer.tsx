import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-secondary text-white pt-10 pb-5">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and tagline */}
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="font-bold text-white">V</span>
              </div>
              <span className="font-bold text-xl">varlanagday</span>
            </Link>
            <p className="text-gray-400 text-sm">
              Futbol tahminleri ve analizleri için Türkiye'nin en iyi platformu.
            </p>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-gray-400 hover:text-accent">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent">
                <Instagram size={20} />
              </a>
              <a href="mailto:info@varlanagday.com" className="text-gray-400 hover:text-accent">
                <Mail size={20} />
              </a>
            </div>
          </div>

          {/* Links 1 */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Ligler</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/?lig=Super+Lig" className="text-gray-400 hover:text-accent transition-colors">
                  Süper Lig
                </Link>
              </li>
              <li>
                <Link to="/?lig=Premier+Lig" className="text-gray-400 hover:text-accent transition-colors">
                  Premier Lig
                </Link>
              </li>
              <li>
                <Link to="/?lig=La+Liga" className="text-gray-400 hover:text-accent transition-colors">
                  La Liga
                </Link>
              </li>
              <li>
                <Link to="/?lig=Bundesliga" className="text-gray-400 hover:text-accent transition-colors">
                  Bundesliga
                </Link>
              </li>
              <li>
                <Link to="/?lig=Serie+A" className="text-gray-400 hover:text-accent transition-colors">
                  Serie A
                </Link>
              </li>
              <li>
                <Link to="/?lig=Ligue+1" className="text-gray-400 hover:text-accent transition-colors">
                  Ligue 1
                </Link>
              </li>
            </ul>
          </div>

          {/* Links 2 */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Takımlar</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/?takim=Galatasaray" className="text-gray-400 hover:text-accent transition-colors">
                  Galatasaray
                </Link>
              </li>
              <li>
                <Link to="/?takim=Fenerbahçe" className="text-gray-400 hover:text-accent transition-colors">
                  Fenerbahçe
                </Link>
              </li>
              <li>
                <Link to="/?takim=Beşiktaş" className="text-gray-400 hover:text-accent transition-colors">
                  Beşiktaş
                </Link>
              </li>
              <li>
                <Link to="/?takim=Trabzonspor" className="text-gray-400 hover:text-accent transition-colors">
                  Trabzonspor
                </Link>
              </li>
              <li>
                <Link to="/?takim=Manchester+City" className="text-gray-400 hover:text-accent transition-colors">
                  Manchester City
                </Link>
              </li>
              <li>
                <Link to="/?takim=Real+Madrid" className="text-gray-400 hover:text-accent transition-colors">
                  Real Madrid
                </Link>
              </li>
            </ul>
          </div>

          {/* Links 3 */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Hızlı Bağlantılar</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-accent transition-colors">
                  Ana Sayfa
                </Link>
              </li>
              <li>
                <Link to="/hakkinda" className="text-gray-400 hover:text-accent transition-colors">
                  Hakkımızda
                </Link>
              </li>
              <li>
                <Link to="/hakkinda#kullanim-kosullari" className="text-gray-400 hover:text-accent transition-colors">
                  Kullanım Koşulları
                </Link>
              </li>
              <li>
                <Link to="/hakkinda#gizlilik-politikasi" className="text-gray-400 hover:text-accent transition-colors">
                  Gizlilik Politikası
                </Link>
              </li>
              <li>
                <Link to="/hakkinda#iletisim" className="text-gray-400 hover:text-accent transition-colors">
                  İletişim
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-5">
          <p className="text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} varlanagday. Tüm hakları saklıdır.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;