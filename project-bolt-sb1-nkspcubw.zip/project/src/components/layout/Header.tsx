import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, ChevronDown, User, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import LoginModal from '../auth/LoginModal';
import RegisterModal from '../auth/RegisterModal';

const Header: React.FC = () => {
  const { user, isAuthenticated, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const toggleUserMenu = () => {
    setShowUserMenu(!showUserMenu);
  };

  const handleLogout = () => {
    logout();
    setShowUserMenu(false);
  };

  return (
    <header className="bg-secondary text-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="font-bold text-white">V</span>
            </div>
            <span className="font-bold text-xl">varlanagday</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link to="/" className="py-2 hover:text-accent transition-colors">Ana Sayfa</Link>
            <div className="relative group">
              <button className="py-2 flex items-center hover:text-accent transition-colors">
                Ligler <ChevronDown size={16} className="ml-1" />
              </button>
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                <Link to="/?lig=Super+Lig" className="block px-4 py-2 text-gray-800 hover:bg-gray-100">Süper Lig</Link>
                <Link to="/?lig=Premier+Lig" className="block px-4 py-2 text-gray-800 hover:bg-gray-100">Premier Lig</Link>
                <Link to="/?lig=La+Liga" className="block px-4 py-2 text-gray-800 hover:bg-gray-100">La Liga</Link>
                <Link to="/?lig=Bundesliga" className="block px-4 py-2 text-gray-800 hover:bg-gray-100">Bundesliga</Link>
                <Link to="/?lig=Serie+A" className="block px-4 py-2 text-gray-800 hover:bg-gray-100">Serie A</Link>
                <Link to="/?lig=Ligue+1" className="block px-4 py-2 text-gray-800 hover:bg-gray-100">Ligue 1</Link>
              </div>
            </div>
            <Link to="/hakkinda" className="py-2 hover:text-accent transition-colors">Hakkında</Link>
          </nav>

          {/* Auth Section */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={toggleUserMenu}
                  className="flex items-center space-x-2 py-2 px-3 bg-primary-dark rounded-md hover:bg-primary transition-colors"
                >
                  <User size={16} />
                  <span>{user?.name}</span>
                  <ChevronDown size={16} />
                </button>
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
                    <button
                      onClick={handleLogout}
                      className="flex items-center w-full px-4 py-2 text-gray-800 hover:bg-gray-100"
                    >
                      <LogOut size={16} className="mr-2" />
                      Çıkış Yap
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <button
                  onClick={() => setShowLoginModal(true)}
                  className="py-2 px-4 border border-white rounded-md hover:bg-white hover:text-secondary transition-colors"
                >
                  Giriş
                </button>
                <button
                  onClick={() => setShowRegisterModal(true)}
                  className="py-2 px-4 bg-primary rounded-md hover:bg-primary-dark transition-colors"
                >
                  Kayıt Ol
                </button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMobileMenu}
            className="md:hidden text-white focus:outline-none"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-secondary-light">
          <div className="container mx-auto px-4 py-3">
            <nav className="flex flex-col space-y-3">
              <Link 
                to="/" 
                className="py-2 hover:text-accent transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Ana Sayfa
              </Link>
              <div className="py-2">
                <div className="flex items-center hover:text-accent transition-colors mb-2">
                  Ligler
                </div>
                <div className="pl-4 flex flex-col space-y-2">
                  <Link 
                    to="/?lig=Super+Lig" 
                    className="text-gray-300 hover:text-accent transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Süper Lig
                  </Link>
                  <Link 
                    to="/?lig=Premier+Lig" 
                    className="text-gray-300 hover:text-accent transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Premier Lig
                  </Link>
                  <Link 
                    to="/?lig=La+Liga" 
                    className="text-gray-300 hover:text-accent transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    La Liga
                  </Link>
                  <Link 
                    to="/?lig=Bundesliga" 
                    className="text-gray-300 hover:text-accent transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Bundesliga
                  </Link>
                  <Link 
                    to="/?lig=Serie+A" 
                    className="text-gray-300 hover:text-accent transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Serie A
                  </Link>
                  <Link 
                    to="/?lig=Ligue+1" 
                    className="text-gray-300 hover:text-accent transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Ligue 1
                  </Link>
                </div>
              </div>
              <Link 
                to="/hakkinda" 
                className="py-2 hover:text-accent transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Hakkında
              </Link>
              
              {/* Mobile Auth Section */}
              <div className="pt-4 border-t border-gray-700 mt-2">
                {isAuthenticated ? (
                  <>
                    <div className="flex items-center space-x-2 py-2">
                      <User size={16} />
                      <span>{user?.name}</span>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="flex items-center space-x-2 py-2 text-red-400 hover:text-red-300 transition-colors"
                    >
                      <LogOut size={16} />
                      <span>Çıkış Yap</span>
                    </button>
                  </>
                ) : (
                  <div className="flex flex-col space-y-3">
                    <button
                      onClick={() => {
                        setShowLoginModal(true);
                        setMobileMenuOpen(false);
                      }}
                      className="py-2 px-4 border border-white rounded-md text-center"
                    >
                      Giriş
                    </button>
                    <button
                      onClick={() => {
                        setShowRegisterModal(true);
                        setMobileMenuOpen(false);
                      }}
                      className="py-2 px-4 bg-primary rounded-md text-center"
                    >
                      Kayıt Ol
                    </button>
                  </div>
                )}
              </div>
            </nav>
          </div>
        </div>
      )}

      {/* Auth Modals */}
      {showLoginModal && (
        <LoginModal onClose={() => setShowLoginModal(false)} onRegisterClick={() => {
          setShowLoginModal(false);
          setShowRegisterModal(true);
        }} />
      )}
      
      {showRegisterModal && (
        <RegisterModal onClose={() => setShowRegisterModal(false)} onLoginClick={() => {
          setShowRegisterModal(false);
          setShowLoginModal(true);
        }} />
      )}
    </header>
  );
};

export default Header;