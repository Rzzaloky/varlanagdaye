import React, { useState } from 'react';
import { usePrediction } from '../../context/PredictionContext';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

interface VotingPollProps {
  matchId: string;
}

const VotingPoll: React.FC<VotingPollProps> = ({ matchId }) => {
  const { getMatchById, getPredictionForMatch, voteForTeam, loading } = usePrediction();
  const { isAuthenticated } = useAuth();
  const [hasVoted, setHasVoted] = useState(false);
  
  const match = getMatchById(matchId);
  const prediction = getPredictionForMatch(matchId);
  
  if (!match) return null;
  
  const { homeTeam, awayTeam } = match;
  
  // Total votes
  const totalVotes = prediction ? (
    prediction.communityVotes.homeTeam +
    prediction.communityVotes.awayTeam +
    prediction.communityVotes.draw
  ) : 0;
  
  // Vote percentages
  const homePercent = totalVotes > 0 
    ? Math.round((prediction?.communityVotes.homeTeam || 0) / totalVotes * 100) 
    : 0;
  
  const awayPercent = totalVotes > 0 
    ? Math.round((prediction?.communityVotes.awayTeam || 0) / totalVotes * 100) 
    : 0;
  
  const drawPercent = totalVotes > 0 
    ? Math.round((prediction?.communityVotes.draw || 0) / totalVotes * 100) 
    : 0;
  
  const handleVote = async (teamId: string) => {
    if (!isAuthenticated) {
      toast.error('Oy vermek için giriş yapmalısınız');
      return;
    }
    
    try {
      await voteForTeam(matchId, teamId);
      setHasVoted(true);
      toast.success('Oyunuz kaydedildi. Teşekkürler!');
    } catch (error) {
      toast.error('Oy verirken bir hata oluştu');
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold mb-4 text-center">Sence hangi takım kazanır?</h3>
      
      {hasVoted || prediction ? (
        // Results view
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="font-medium">{homeTeam.name}</span>
              <span className="text-sm">{homePercent}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div 
                className="bg-primary h-4 rounded-full"
                style={{ width: `${homePercent}%` }}
              ></div>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="font-medium">Beraberlik</span>
              <span className="text-sm">{drawPercent}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div 
                className="bg-accent h-4 rounded-full"
                style={{ width: `${drawPercent}%` }}
              ></div>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="font-medium">{awayTeam.name}</span>
              <span className="text-sm">{awayPercent}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div 
                className="bg-secondary h-4 rounded-full"
                style={{ width: `${awayPercent}%` }}
              ></div>
            </div>
          </div>
          
          <div className="text-center text-sm text-gray-500 mt-4">
            Toplam {totalVotes} kişi oy kullandı
          </div>
        </div>
      ) : (
        // Voting form
        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => handleVote(homeTeam.id)}
            disabled={loading}
            className="flex flex-col items-center p-3 border border-gray-200 rounded-lg hover:bg-primary hover:text-white hover:border-primary transition-colors"
          >
            <img 
              src={homeTeam.logo} 
              alt={homeTeam.name}
              className="w-12 h-12 object-contain mb-2"
            />
            <span className="font-medium text-sm">{homeTeam.name}</span>
          </button>
          
          <button
            onClick={() => handleVote('draw')}
            disabled={loading}
            className="flex flex-col items-center p-3 border border-gray-200 rounded-lg hover:bg-accent hover:text-white hover:border-accent transition-colors"
          >
            <div className="w-12 h-12 flex items-center justify-center mb-2">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 12H16M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <span className="font-medium text-sm">Beraberlik</span>
          </button>
          
          <button
            onClick={() => handleVote(awayTeam.id)}
            disabled={loading}
            className="flex flex-col items-center p-3 border border-gray-200 rounded-lg hover:bg-secondary hover:text-white hover:border-secondary transition-colors"
          >
            <img 
              src={awayTeam.logo} 
              alt={awayTeam.name}
              className="w-12 h-12 object-contain mb-2"
            />
            <span className="font-medium text-sm">{awayTeam.name}</span>
          </button>
        </div>
      )}
      
      {!isAuthenticated && !hasVoted && (
        <div className="text-center text-sm text-gray-500 mt-4">
          Oy vermek için giriş yapmalısınız
        </div>
      )}
    </div>
  );
};

export default VotingPoll;