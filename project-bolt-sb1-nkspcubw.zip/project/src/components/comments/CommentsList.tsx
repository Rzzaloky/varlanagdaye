import React, { useState } from 'react';
import { ThumbsUp, Flag } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';
import { mockedComments } from '../../data/mockedData';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

interface CommentsListProps {
  matchId: string;
}

const CommentsList: React.FC<CommentsListProps> = ({ matchId }) => {
  const { isAuthenticated } = useAuth();
  const [comments, setComments] = useState(
    mockedComments.filter(comment => comment.matchId === matchId)
  );
  const [newComment, setNewComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleLike = (commentId: string) => {
    if (!isAuthenticated) {
      toast.error('Yorum beğenmek için giriş yapmalısınız');
      return;
    }
    
    setComments(prevComments => 
      prevComments.map(comment => 
        comment.id === commentId
          ? { ...comment, likes: comment.likes + 1 }
          : comment
      )
    );
    
    toast.success('Yorum beğenildi');
  };
  
  const handleReport = (commentId: string) => {
    if (!isAuthenticated) {
      toast.error('Yorum bildirmek için giriş yapmalısınız');
      return;
    }
    
    toast.success('Yorum rapor edildi. Teşekkürler!');
  };
  
  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isAuthenticated) {
      toast.error('Yorum yapmak için giriş yapmalısınız');
      return;
    }
    
    if (!newComment.trim()) {
      toast.error('Boş yorum gönderemezsiniz');
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      const newCommentObj = {
        id: `comment-${Date.now()}`,
        matchId,
        userId: 'user-current',
        userName: 'Kullanıcı',
        text: newComment,
        created: new Date().toISOString(),
        likes: 0
      };
      
      setComments(prevComments => [newCommentObj, ...prevComments]);
      setNewComment('');
      setIsSubmitting(false);
      toast.success('Yorumunuz eklendi');
    }, 1000);
  };
  
  if (comments.length === 0 && !isAuthenticated) {
    return (
      <div className="bg-gray-50 rounded-lg p-6 text-center">
        <p className="text-gray-500 mb-3">Bu maç için henüz yorum yok.</p>
        <p className="text-sm text-gray-400">
          Yorum yapmak için <span className="text-primary">giriş yapmalısınız</span>.
        </p>
      </div>
    );
  }
  
  return (
    <div>
      {/* Comment form */}
      {isAuthenticated && (
        <form onSubmit={handleSubmitComment} className="mb-6">
          <div className="mb-3">
            <label htmlFor="comment" className="sr-only">Yorumunuz</label>
            <textarea
              id="comment"
              rows={3}
              className="input"
              placeholder="Maç hakkındaki düşüncelerinizi paylaşın..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              required
            ></textarea>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className="btn btn-primary"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Gönderiliyor...' : 'Yorum Gönder'}
            </button>
          </div>
        </form>
      )}
      
      {/* Comments list */}
      <div className="space-y-4">
        {comments.length === 0 ? (
          <div className="bg-gray-50 rounded-lg p-6 text-center">
            <p className="text-gray-500">Bu maç için henüz yorum yok. İlk yorumu siz yapın!</p>
          </div>
        ) : (
          comments.map(comment => (
            <div key={comment.id} className="bg-white p-4 rounded-lg shadow-sm">
              <div className="flex justify-between items-start">
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-full bg-secondary text-white flex items-center justify-center font-bold mr-3">
                    {comment.userName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-medium">{comment.userName}</h4>
                    <p className="text-sm text-gray-500">
                      {formatDistanceToNow(new Date(comment.created), { 
                        addSuffix: true,
                        locale: tr
                      })}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleReport(comment.id)}
                  className="text-gray-400 hover:text-gray-600"
                  aria-label="Yorumu bildir"
                >
                  <Flag size={16} />
                </button>
              </div>
              <p className="mt-3 text-gray-700">{comment.text}</p>
              <div className="mt-3 flex">
                <button
                  onClick={() => handleLike(comment.id)}
                  className="flex items-center text-gray-500 hover:text-primary"
                >
                  <ThumbsUp size={16} className="mr-1" />
                  <span>{comment.likes}</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default CommentsList;