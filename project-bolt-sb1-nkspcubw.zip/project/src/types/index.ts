export interface Team {
  id: string;
  name: string;
  league: League;
  logo: string;
  form: number; // 0-10 rating
  lastFiveGames: number; // points from last 5 games
  homeAdvantage: number; // 0-10 rating
  awayDisadvantage: number; // 0-10 rating
  averageGoalsFor: number;
  averageGoalsAgainst: number;
}

export type League = 
  | 'Super Lig' 
  | 'Premier Lig' 
  | 'La Liga' 
  | 'Bundesliga' 
  | 'Serie A' 
  | 'Ligue 1';

export interface Match {
  id: string;
  homeTeam: Team;
  awayTeam: Team;
  date: string;
  stadium: string;
  league: League;
  status: 'upcoming' | 'live' | 'completed';
}

export interface MatchPrediction {
  id: string;
  homeTeam: Team;
  awayTeam: Team;
  homeWinProbability: number;
  awayWinProbability: number;
  drawProbability: number;
  estimatedHomeGoals: number;
  estimatedAwayGoals: number;
  created: string;
  communityVotes: {
    homeTeam: number;
    awayTeam: number;
    draw: number;
  };
}

export interface Comment {
  id: string;
  matchId: string;
  userId: string;
  userName: string;
  text: string;
  created: string;
  likes: number;
}