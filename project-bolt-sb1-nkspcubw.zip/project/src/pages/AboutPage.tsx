import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Mail, MapPin, Phone } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="py-10">
      <div className="container">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link
            to="/"
            className="inline-flex items-center text-primary hover:text-primary-dark font-medium"
          >
            <ArrowLeft size={16} className="mr-1" />
            Ana Sayfaya Dön
          </Link>
        </div>
        
        {/* About Us Section */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="bg-secondary text-white p-6">
            <h1 className="text-2xl md:text-3xl font-bold">Hakkımızda</h1>
          </div>
          
          <div className="p-6">
            <div className="prose max-w-none">
              <p>
                <strong>varlanagday</strong>, Türk futbol tutkunlarının maç tahminleri, analizler ve yorumlar yapabileceği, 
                Türkiye Süper Lig ve Avrupa'nın büyük liglerindeki maçlara odaklanan bir platformdur.
              </p>
              
              <p>
                Platformumuz, gelişmiş tahmin algoritmaları kullanarak maç sonuçlarını tahmin etmenize, 
                diğer futbolseverlerle görüş alışverişinde bulunmanıza ve favori takımlarınızı desteklemenize olanak tanır.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">Misyonumuz</h2>
              <p>
                Futbol tutkunlarına, verilere dayalı tahminler ve samimi bir topluluk deneyimi sunarak 
                maç izleme deneyimlerini zenginleştirmek ve futbola olan tutkularını artırmak.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">Neden varlanagday?</h2>
              <ul className="list-disc pl-5">
                <li>Türkiye odaklı, Türkçe içerik</li>
                <li>Gelişmiş tahmin algoritmaları</li>
                <li>Canlı taraftar yorumları ve oylamaları</li>
                <li>Süper Lig ve Avrupa'nın büyük ligleri</li>
                <li>Kullanıcı dostu arayüz</li>
                <li>Tamamen ücretsiz kullanım</li>
              </ul>
            </div>
          </div>
        </div>
        
        {/* Terms and Conditions */}
        <div id="kullanim-kosullari" className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="bg-secondary text-white p-6">
            <h2 className="text-2xl font-bold">Kullanım Koşulları</h2>
          </div>
          
          <div className="p-6">
            <div className="prose max-w-none">
              <p>
                varlanagday hizmetlerini kullanırken aşağıdaki koşulları kabul etmiş sayılırsınız:
              </p>
              
              <ol className="list-decimal pl-5">
                <li>
                  <strong>Hesap Güvenliği:</strong> Hesabınızın güvenliğinden siz sorumlusunuz. Şifrenizi kimseyle paylaşmayın.
                </li>
                
                <li>
                  <strong>İçerik Kuralları:</strong> Platformda paylaştığınız tüm içerikler uygun ve saygılı olmalıdır. 
                  Hakaret, ırkçılık, cinsiyet ayrımcılığı veya yasa dışı içerikler paylaşmak yasaktır.
                </li>
                
                <li>
                  <strong>Telif Hakkı:</strong> Başkalarının telif haklarını ihlal eden içerikler paylaşmayın.
                </li>
                
                <li>
                  <strong>Sorumluluk Reddi:</strong> Tahminlerimiz, geçmiş verilere ve algoritmalara dayanmaktadır. 
                  Ancak futbol doğası gereği tahmin edilemez olduğundan, bahis amaçlı kullanımdan doğabilecek kayıplardan 
                  sorumlu değiliz.
                </li>
                
                <li>
                  <strong>Hesap İptali:</strong> Kurallara uymayan kullanıcıların hesapları askıya alınabilir veya silinebilir.
                </li>
              </ol>
            </div>
          </div>
        </div>
        
        {/* Privacy Policy */}
        <div id="gizlilik-politikasi" className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="bg-secondary text-white p-6">
            <h2 className="text-2xl font-bold">Gizlilik Politikası</h2>
          </div>
          
          <div className="p-6">
            <div className="prose max-w-none">
              <p>
                varlanagday olarak kullanıcılarımızın gizliliğine saygı duyuyoruz. Kişisel verilerinizi nasıl topladığımız 
                ve kullandığımız hakkında bilgi sahibi olmanız gerektiğine inanıyoruz.
              </p>
              
              <h3 className="text-lg font-semibold mt-4 mb-2">Toplanan Bilgiler</h3>
              <ul className="list-disc pl-5">
                <li>İsim, e-posta adresi gibi hesap bilgileri</li>
                <li>Tahminler, yorumlar ve oylamalar</li>
                <li>Kullanım alışkanlıkları ve site ziyaretleri</li>
                <li>IP adresi ve tarayıcı bilgileri</li>
              </ul>
              
              <h3 className="text-lg font-semibold mt-4 mb-2">Bilgilerin Kullanımı</h3>
              <ul className="list-disc pl-5">
                <li>Hizmetlerimizi sağlamak ve iyileştirmek için</li>
                <li>Size özel içerik ve öneriler sunmak için</li>
                <li>Güvenlik ve doğrulama amacıyla</li>
                <li>İstatistiksel analiz için</li>
              </ul>
              
              <h3 className="text-lg font-semibold mt-4 mb-2">Bilgi Paylaşımı</h3>
              <p>
                Kişisel bilgilerinizi üçüncü taraflarla paylaşmıyoruz. Ancak, yasal zorunluluk olması durumunda 
                yetkili mercilerle paylaşabiliriz.
              </p>
              
              <h3 className="text-lg font-semibold mt-4 mb-2">Çerezler</h3>
              <p>
                Sitemizdeki deneyiminizi kişiselleştirmek için çerezler kullanıyoruz. Tarayıcı ayarlarınızdan 
                çerezleri devre dışı bırakabilirsiniz.
              </p>
            </div>
          </div>
        </div>
        
        {/* Contact Section */}
        <div id="iletisim" className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="bg-secondary text-white p-6">
            <h2 className="text-2xl font-bold">İletişim</h2>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-4">Bize Ulaşın</h3>
                
                <div className="space-y-4">
                  <div className="flex items-start">
                    <Mail className="text-primary mt-1 mr-3" size={20} />
                    <div>
                      <h4 className="font-medium">E-posta</h4>
                      <a href="mailto:info@varlanagday.com" className="text-primary hover:text-primary-dark">
                        info@varlanagday.com
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Phone className="text-primary mt-1 mr-3" size={20} />
                    <div>
                      <h4 className="font-medium">Telefon</h4>
                      <a href="tel:+902121234567" className="text-primary hover:text-primary-dark">
                        +90 (212) 123 45 67
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <MapPin className="text-primary mt-1 mr-3" size={20} />
                    <div>
                      <h4 className="font-medium">Adres</h4>
                      <address className="not-italic">
                        Barbaros Bulvarı, No: 123<br />
                        Beşiktaş, İstanbul<br />
                        Türkiye
                      </address>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold mb-4">İletişim Formu</h3>
                
                <form className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-gray-700 text-sm font-medium mb-1">
                      Ad Soyad
                    </label>
                    <input id="name" type="text" className="input" required />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-gray-700 text-sm font-medium mb-1">
                      E-posta
                    </label>
                    <input id="email" type="email" className="input" required />
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block text-gray-700 text-sm font-medium mb-1">
                      Mesajınız
                    </label>
                    <textarea id="message" rows={4} className="input" required></textarea>
                  </div>
                  
                  <div>
                    <button type="submit" className="btn btn-primary">
                      Gönder
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;