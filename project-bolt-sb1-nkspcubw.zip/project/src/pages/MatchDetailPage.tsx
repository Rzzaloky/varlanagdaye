import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, MapPin, Clock, Users, Award } from 'lucide-react';
import { usePrediction } from '../context/PredictionContext';
import VotingPoll from '../components/votes/VotingPoll';
import CommentsList from '../components/comments/CommentsList';
import PredictionResult from '../components/prediction/PredictionResult';
import toast from 'react-hot-toast';

const MatchDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getMatchById, getPredictionForMatch, predictMatch, loading } = usePrediction();
  const [generatingPrediction, setGeneratingPrediction] = useState(false);
  
  // Get match data
  const match = id ? getMatchById(id) : undefined;
  
  // Get existing prediction or create a new one
  const [prediction, setPrediction] = useState(id ? getPredictionForMatch(id) : undefined);
  
  // If no prediction exists for this match, generate one
  useEffect(() => {
    const generatePrediction = async () => {
      if (match && !prediction && !generatingPrediction) {
        setGeneratingPrediction(true);
        
        try {
          // Create a prediction using the match teams
          // In a real app, we would use the API
          const result = await predictMatch();
          if (result) {
            setPrediction(result);
          }
        } catch (error) {
          toast.error('Tahmin oluşturulurken bir hata oluştu');
        } finally {
          setGeneratingPrediction(false);
        }
      }
    };
    
    generatePrediction();
  }, [match, prediction, generatingPrediction]);
  
  if (!match) {
    return (
      <div className="py-10">
        <div className="container">
          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Maç Bulunamadı</h2>
            <p className="text-gray-600 mb-6">
              Aradığınız maç detayları bulunamadı veya bu maç artık mevcut değil.
            </p>
            <Link
              to="/"
              className="inline-flex items-center text-primary hover:text-primary-dark font-medium"
            >
              <ArrowLeft size={16} className="mr-1" />
              Ana Sayfaya Dön
            </Link>
          </div>
        </div>
      </div>
    );
  }
  
  const { homeTeam, awayTeam, date, stadium, league } = match;
  
  // Format date
  const matchDate = new Date(date);
  const formattedDate = matchDate.toLocaleDateString('tr-TR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
  
  const formattedTime = matchDate.toLocaleTimeString('tr-TR', {
    hour: '2-digit',
    minute: '2-digit'
  });
  
  return (
    <div className="py-10">
      <div className="container">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link
            to="/"
            className="inline-flex items-center text-primary hover:text-primary-dark font-medium"
          >
            <ArrowLeft size={16} className="mr-1" />
            Ana Sayfaya Dön
          </Link>
        </div>
        
        {/* Match Header */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="bg-secondary text-white p-6">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <h1 className="text-2xl md:text-3xl font-bold mb-4 md:mb-0 text-center md:text-left">
                {homeTeam.name} vs {awayTeam.name}
              </h1>
              
              <div className="bg-white/10 px-4 py-2 rounded-lg">
                <span className="text-white font-semibold">{league}</span>
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
              {/* Home Team */}
              <div className="flex flex-col items-center">
                <img 
                  src={homeTeam.logo} 
                  alt={homeTeam.name}
                  className="w-20 h-20 object-contain mb-3"
                />
                <h2 className="text-xl font-semibold">{homeTeam.name}</h2>
                <div className="mt-2">
                  <span className="badge badge-primary">
                    Form: {homeTeam.form}/10
                  </span>
                </div>
              </div>
              
              {/* Match Info */}
              <div className="flex flex-col items-center">
                <div className="text-3xl font-bold text-secondary mb-4">VS</div>
                <div className="space-y-2">
                  <div className="flex items-center text-gray-600">
                    <Calendar size={16} className="mr-2" />
                    <span>{formattedDate}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Clock size={16} className="mr-2" />
                    <span>{formattedTime}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <MapPin size={16} className="mr-2" />
                    <span>{stadium}</span>
                  </div>
                </div>
              </div>
              
              {/* Away Team */}
              <div className="flex flex-col items-center">
                <img 
                  src={awayTeam.logo} 
                  alt={awayTeam.name}
                  className="w-20 h-20 object-contain mb-3"
                />
                <h2 className="text-xl font-semibold">{awayTeam.name}</h2>
                <div className="mt-2">
                  <span className="badge badge-secondary">
                    Form: {awayTeam.form}/10
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Content Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            {/* Match Prediction */}
            <section className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="bg-secondary text-white p-4">
                <h2 className="text-xl font-semibold flex items-center">
                  <Award className="mr-2" size={20} />
                  Maç Tahmini
                </h2>
              </div>
              <div className="p-4">
                {prediction ? (
                  <PredictionResult prediction={prediction} />
                ) : (
                  <div className="bg-gray-50 p-6 text-center rounded-lg">
                    <p className="text-gray-500">
                      {loading ? 'Tahmin oluşturuluyor...' : 'Bu maç için henüz tahmin bulunmuyor.'}
                    </p>
                  </div>
                )}
              </div>
            </section>
            
            {/* Team Stats Comparison */}
            <section className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="bg-secondary text-white p-4">
                <h2 className="text-xl font-semibold flex items-center">
                  <Users className="mr-2" size={20} />
                  Takım İstatistikleri
                </h2>
              </div>
              <div className="p-6">
                <div className="space-y-6">
                  {/* Form */}
                  <div>
                    <h3 className="font-medium mb-3">Form</h3>
                    <div className="flex items-center">
                      <div className="w-1/2 pr-2">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm">{homeTeam.name}</span>
                          <span className="text-xs">{homeTeam.form}/10</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className="bg-primary h-2.5 rounded-full" 
                            style={{ width: `${homeTeam.form * 10}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="w-1/2 pl-2">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs">{awayTeam.form}/10</span>
                          <span className="text-sm">{awayTeam.name}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className="bg-secondary h-2.5 rounded-full" 
                            style={{ width: `${awayTeam.form * 10}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Last 5 Games */}
                  <div>
                    <h3 className="font-medium mb-3">Son 5 Maç Puanı</h3>
                    <div className="flex items-center">
                      <div className="w-1/2 pr-2">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm">{homeTeam.name}</span>
                          <span className="text-xs">{homeTeam.lastFiveGames} puan</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className="bg-primary h-2.5 rounded-full" 
                            style={{ width: `${(homeTeam.lastFiveGames / 15) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="w-1/2 pl-2">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs">{awayTeam.lastFiveGames} puan</span>
                          <span className="text-sm">{awayTeam.name}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className="bg-secondary h-2.5 rounded-full" 
                            style={{ width: `${(awayTeam.lastFiveGames / 15) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Home/Away Advantage */}
                  <div>
                    <h3 className="font-medium mb-3">Ev Sahibi/Deplasman Faktörü</h3>
                    <div className="flex items-center">
                      <div className="w-1/2 pr-2">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm">Ev Avantajı</span>
                          <span className="text-xs">{homeTeam.homeAdvantage}/10</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className="bg-primary h-2.5 rounded-full" 
                            style={{ width: `${homeTeam.homeAdvantage * 10}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="w-1/2 pl-2">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs">{awayTeam.awayDisadvantage}/10</span>
                          <span className="text-sm">Deplasman Dezavantajı</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className="bg-secondary h-2.5 rounded-full" 
                            style={{ width: `${awayTeam.awayDisadvantage * 10}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Average Goals */}
                  <div>
                    <h3 className="font-medium mb-3">Ortalama Goller</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium mb-2">Atılan Goller</h4>
                        <div className="flex items-center">
                          <div className="w-1/2 pr-2">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs">{homeTeam.name}</span>
                              <span className="text-xs">{homeTeam.averageGoalsFor}</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div 
                                className="bg-primary h-2.5 rounded-full" 
                                style={{ width: `${Math.min(homeTeam.averageGoalsFor / 3 * 100, 100)}%` }}
                              ></div>
                            </div>
                          </div>
                          <div className="w-1/2 pl-2">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs">{awayTeam.averageGoalsFor}</span>
                              <span className="text-xs">{awayTeam.name}</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div 
                                className="bg-secondary h-2.5 rounded-full" 
                                style={{ width: `${Math.min(awayTeam.averageGoalsFor / 3 * 100, 100)}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2">Yenilen Goller</h4>
                        <div className="flex items-center">
                          <div className="w-1/2 pr-2">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs">{homeTeam.name}</span>
                              <span className="text-xs">{homeTeam.averageGoalsAgainst}</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div 
                                className="bg-primary h-2.5 rounded-full" 
                                style={{ width: `${Math.min(homeTeam.averageGoalsAgainst / 3 * 100, 100)}%` }}
                              ></div>
                            </div>
                          </div>
                          <div className="w-1/2 pl-2">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs">{awayTeam.averageGoalsAgainst}</span>
                              <span className="text-xs">{awayTeam.name}</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div 
                                className="bg-secondary h-2.5 rounded-full" 
                                style={{ width: `${Math.min(awayTeam.averageGoalsAgainst / 3 * 100, 100)}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            
            {/* Comments Section */}
            <section className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="bg-secondary text-white p-4">
                <h2 className="text-xl font-semibold">Taraftar Yorumları</h2>
              </div>
              <div className="p-6">
                <CommentsList matchId={id} />
              </div>
            </section>
          </div>
          
          {/* Right Column */}
          <div className="space-y-8">
            {/* Voting Poll */}
            <section>
              <VotingPoll matchId={id} />
            </section>
            
            {/* Related Matches */}
            <section className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="bg-secondary text-white p-4">
                <h2 className="text-lg font-semibold">Aynı Ligdeki Diğer Maçlar</h2>
              </div>
              <div className="p-4">
                <MatchesList league={league} limit={3} />
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MatchDetailPage;