import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import PredictionForm from '../components/prediction/PredictionForm';
import MatchesList from '../components/matches/MatchesList';
import { usePrediction } from '../context/PredictionContext';
import type { League } from '../types';

const HomePage: React.FC = () => {
  const location = useLocation();
  const { teams } = usePrediction();
  const [league, setLeague] = useState<League | undefined>(undefined);
  
  // Get all available leagues
  const leagues = Array.from(new Set(teams.map(team => team.league)));
  
  // Check for league in URL
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const leagueParam = params.get('lig');
    
    if (leagueParam) {
      // Check if the league param is valid
      const decodedLeague = decodeURIComponent(leagueParam).replace('+', ' ');
      if (leagues.includes(decodedLeague as League)) {
        setLeague(decodedLeague as League);
      }
    } else {
      setLeague(undefined);
    }
  }, [location.search, leagues]);
  
  return (
    <div className="py-10">
      <div className="container">
        {/* Hero Banner */}
        <div className="relative mb-12">
          <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl overflow-hidden shadow-xl">
            <div className="bg-[url('https://images.pexels.com/photos/243752/pexels-photo-243752.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center bg-blend-overlay bg-black/30">
              <div className="py-16 px-8 md:py-20 md:px-12 text-white">
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
                  Futbol Tahminleri ve Analizleri
                </h1>
                <p className="text-lg md:text-xl max-w-xl mb-8">
                  Türkiye Süper Lig ve Avrupa'nın büyük liglerindeki maçlar için tahminler, analizler ve taraftar görüşleri.
                </p>
                <a 
                  href="#prediction-form"
                  className="inline-block bg-white text-primary hover:bg-accent hover:text-white px-6 py-3 rounded-lg font-medium transition-colors duration-300"
                >
                  Hemen Tahmin Et
                </a>
              </div>
            </div>
          </div>
        </div>
        
        {/* Prediction Form */}
        <section id="prediction-form" className="mb-16">
          <PredictionForm />
        </section>
        
        {/* Upcoming Matches */}
        <section className="mb-16">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-secondary">
              {league ? `${league} Yaklaşan Maçlar` : 'Yaklaşan Maçlar'}
            </h2>
            
            {/* League filter dropdown */}
            <div className="relative">
              <select
                value={league || ''}
                onChange={(e) => {
                  const value = e.target.value;
                  if (value) {
                    window.history.pushState(
                      {},
                      '',
                      `?lig=${encodeURIComponent(value)}`
                    );
                    setLeague(value as League);
                  } else {
                    window.history.pushState({}, '', '/');
                    setLeague(undefined);
                  }
                }}
                className="select py-1 px-3 text-sm min-w-40"
              >
                <option value="">Tüm Ligler</option>
                {leagues.map(league => (
                  <option key={league} value={league}>
                    {league}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          <MatchesList league={league} />
        </section>
        
        {/* Features Section */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-secondary mb-8 text-center">
            Neden varlanagday?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Gelişmiş Analizler</h3>
              <p className="text-gray-600">
                Son 5 maç performansı, ev sahibi avantajı, gol ortalamaları ve daha fazlasını hesaba katan gelişmiş tahmin algoritması.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Taraftar Yorumları</h3>
              <p className="text-gray-600">
                Futbol tutkunlarının maçlar hakkındaki görüşlerini paylaşabildiği canlı tartışma platformu.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Topluluk Tahminleri</h3>
              <p className="text-gray-600">
                Taraftarların oylarıyla oluşan topluluk tahmini ile profesyonel analizleri karşılaştırma imkanı.
              </p>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="bg-gradient-to-r from-secondary to-primary rounded-2xl overflow-hidden shadow-xl">
          <div className="py-12 px-8 text-white text-center">
            <h2 className="text-3xl font-bold mb-4">
              Hemen Başlayın
            </h2>
            <p className="text-lg max-w-xl mx-auto mb-8">
              Favori takımlarınızın maçlarını tahmin edin, yorumlarınızı paylaşın ve futbol tutkunlarıyla etkileşime geçin.
            </p>
            <a 
              href="#prediction-form"
              className="inline-block bg-white text-primary hover:bg-accent hover:text-white px-8 py-3 rounded-lg font-medium transition-colors duration-300"
            >
              Tahmin Et
            </a>
          </div>
        </section>
      </div>
    </div>
  );
};

export default HomePage;