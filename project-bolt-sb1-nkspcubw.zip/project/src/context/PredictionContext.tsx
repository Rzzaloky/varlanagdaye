import React, { createContext, useState, useContext } from 'react';
import { Match, MatchPrediction, Team } from '../types';
import { mockedTeams, mockedMatches } from '../data/mockedData';

interface PredictionContextType {
  teams: Team[];
  matches: Match[];
  predictions: MatchPrediction[];
  selectedHomeTeam: Team | null;
  selectedAwayTeam: Team | null;
  loading: boolean;
  error: string | null;
  setSelectedHomeTeam: (team: Team | null) => void;
  setSelectedAwayTeam: (team: Team | null) => void;
  predictMatch: () => Promise<MatchPrediction | null>;
  getMatchById: (id: string) => Match | undefined;
  getPredictionForMatch: (matchId: string) => MatchPrediction | undefined;
  voteForTeam: (matchId: string, teamId: string) => Promise<void>;
}

const PredictionContext = createContext<PredictionContextType | undefined>(undefined);

export const PredictionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [teams] = useState<Team[]>(mockedTeams);
  const [matches] = useState<Match[]>(mockedMatches);
  const [predictions, setPredictions] = useState<MatchPrediction[]>([]);
  const [selectedHomeTeam, setSelectedHomeTeam] = useState<Team | null>(null);
  const [selectedAwayTeam, setSelectedAwayTeam] = useState<Team | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Helper function to create prediction
  const createPrediction = (homeTeam: Team, awayTeam: Team): MatchPrediction => {
    // In a real application, this would be a complex algorithm based on team statistics
    const homeStrength = homeTeam.form * 1.2 + homeTeam.lastFiveGames * 0.8;
    const awayStrength = awayTeam.form * 0.8 + awayTeam.lastFiveGames * 1.2;
    
    // Calculate win probabilities
    const totalStrength = homeStrength + awayStrength;
    const homeWinProb = Math.min(Math.round((homeStrength / totalStrength) * 100), 90);
    const awayWinProb = Math.min(Math.round((awayStrength / totalStrength) * 100), 90);
    const drawProb = 100 - homeWinProb - awayWinProb;
    
    // Estimated score based on average goals
    const estimatedHomeGoals = Math.round((homeTeam.averageGoalsFor * 0.7 + awayTeam.averageGoalsAgainst * 0.3) * 10) / 10;
    const estimatedAwayGoals = Math.round((awayTeam.averageGoalsFor * 0.6 + homeTeam.averageGoalsAgainst * 0.4) * 10) / 10;
    
    return {
      id: `pred-${Date.now()}`,
      homeTeam,
      awayTeam,
      homeWinProbability: homeWinProb,
      awayWinProbability: awayWinProb,
      drawProbability: drawProb,
      estimatedHomeGoals,
      estimatedAwayGoals,
      created: new Date().toISOString(),
      communityVotes: {
        homeTeam: 0,
        awayTeam: 0,
        draw: 0
      }
    };
  };

  const predictMatch = async (): Promise<MatchPrediction | null> => {
    setLoading(true);
    setError(null);
    
    try {
      // Validation
      if (!selectedHomeTeam || !selectedAwayTeam) {
        throw new Error('Lütfen her iki takımı da seçin');
      }
      
      if (selectedHomeTeam.id === selectedAwayTeam.id) {
        throw new Error('Aynı takımı iki kez seçemezsiniz');
      }
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Create prediction
      const prediction = createPrediction(selectedHomeTeam, selectedAwayTeam);
      
      // Store prediction
      setPredictions(prev => [...prev, prediction]);
      
      setLoading(false);
      return prediction;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Tahmin oluşturulurken bir hata oluştu';
      setError(errorMessage);
      setLoading(false);
      return null;
    }
  };

  const getMatchById = (id: string): Match | undefined => {
    return matches.find(match => match.id === id);
  };

  const getPredictionForMatch = (matchId: string): MatchPrediction | undefined => {
    const match = getMatchById(matchId);
    if (!match) return undefined;
    
    return predictions.find(
      pred => pred.homeTeam.id === match.homeTeam.id && pred.awayTeam.id === match.awayTeam.id
    );
  };

  const voteForTeam = async (matchId: string, teamId: string): Promise<void> => {
    setLoading(true);
    
    try {
      // Find the match
      const match = getMatchById(matchId);
      if (!match) throw new Error('Maç bulunamadı');
      
      // Find existing prediction or create new one
      let prediction = getPredictionForMatch(matchId);
      
      if (!prediction) {
        prediction = createPrediction(match.homeTeam, match.awayTeam);
      }
      
      // Update votes
      const updatedPrediction = { ...prediction };
      
      if (teamId === match.homeTeam.id) {
        updatedPrediction.communityVotes.homeTeam += 1;
      } else if (teamId === match.awayTeam.id) {
        updatedPrediction.communityVotes.awayTeam += 1;
      } else {
        updatedPrediction.communityVotes.draw += 1;
      }
      
      // Update predictions state
      setPredictions(prev => 
        prev.map(p => 
          p.id === prediction?.id ? updatedPrediction : p
        ).concat(prev.find(p => p.id === prediction?.id) ? [] : [updatedPrediction])
      );
      
      setLoading(false);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Oy verirken bir hata oluştu';
      setError(errorMessage);
      setLoading(false);
    }
  };

  return (
    <PredictionContext.Provider
      value={{
        teams,
        matches,
        predictions,
        selectedHomeTeam,
        selectedAwayTeam,
        loading,
        error,
        setSelectedHomeTeam,
        setSelectedAwayTeam,
        predictMatch,
        getMatchById,
        getPredictionForMatch,
        voteForTeam
      }}
    >
      {children}
    </PredictionContext.Provider>
  );
};

export const usePrediction = () => {
  const context = useContext(PredictionContext);
  if (context === undefined) {
    throw new Error('usePrediction must be used within a PredictionProvider');
  }
  return context;
};