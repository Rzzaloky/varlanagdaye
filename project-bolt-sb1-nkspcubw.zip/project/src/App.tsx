import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';

// Pages
import HomePage from './pages/HomePage';
import MatchDetailPage from './pages/MatchDetailPage';
import AboutPage from './pages/AboutPage';

// Components
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';

// Context Providers
import { AuthProvider } from './context/AuthContext';
import { PredictionProvider } from './context/PredictionContext';

function App() {
  return (
    <Router>
      <AuthProvider>
        <PredictionProvider>
          <div className="flex flex-col min-h-screen bg-gray-50">
            <Header />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/mac/:id" element={<MatchDetailPage />} />
                <Route path="/hakkinda" element={<AboutPage />} />
              </Routes>
            </main>
            <Footer />
            <Toaster position="top-center" />
          </div>
        </PredictionProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;