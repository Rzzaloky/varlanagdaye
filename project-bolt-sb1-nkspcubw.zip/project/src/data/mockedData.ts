import { Team, Match, Comment } from '../types';

export const mockedTeams: Team[] = [
  // Süper Lig Teams
  {
    id: 'gs',
    name: 'Galatasaray',
    league: 'Super Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/f/f6/Galatasaray_Sports_Club_Logo.png',
    form: 8.5,
    lastFiveGames: 13,
    homeAdvantage: 9.0,
    awayDisadvantage: 6.5,
    averageGoalsFor: 2.4,
    averageGoalsAgainst: 0.8
  },
  {
    id: 'fb',
    name: 'Fenerbahçe',
    league: 'Super Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/8/89/Fenerbah%C3%A7e.png',
    form: 8.2,
    lastFiveGames: 12,
    homeAdvantage: 8.8,
    awayDisadvantage: 6.8,
    averageGoalsFor: 2.3,
    averageGoalsAgainst: 0.9
  },
  {
    id: 'bjk',
    name: 'Beşiktaş',
    league: 'Super Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/0/08/Be%C5%9Fikta%C5%9F_Logo_Be%C5%9Fikta%C5%9F_Amblem_Be%C5%9Fikta%C5%9F_Arma.png',
    form: 7.5,
    lastFiveGames: 10,
    homeAdvantage: 8.5,
    awayDisadvantage: 7.0,
    averageGoalsFor: 1.9,
    averageGoalsAgainst: 1.1
  },
  {
    id: 'ts',
    name: 'Trabzonspor',
    league: 'Super Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/en/8/8d/Trabzonspor_logo.svg',
    form: 7.2,
    lastFiveGames: 9,
    homeAdvantage: 8.3,
    awayDisadvantage: 6.7,
    averageGoalsFor: 1.8,
    averageGoalsAgainst: 1.2
  },
  {
    id: 'antalyaspor',
    name: 'Antalyaspor',
    league: 'Super Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/9/9d/Antalyaspor_logo.png',
    form: 6.8,
    lastFiveGames: 8,
    homeAdvantage: 7.5,
    awayDisadvantage: 6.5,
    averageGoalsFor: 1.5,
    averageGoalsAgainst: 1.4
  },
  {
    id: 'basaksehir',
    name: 'Başakşehir',
    league: 'Super Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/5/5c/%C4%B0BB_logo.png',
    form: 7.0,
    lastFiveGames: 9,
    homeAdvantage: 7.8,
    awayDisadvantage: 6.8,
    averageGoalsFor: 1.6,
    averageGoalsAgainst: 1.3
  },
  {
    id: 'konyaspor',
    name: 'Konyaspor',
    league: 'Super Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/9/9f/Konyaspor_logo.png',
    form: 6.5,
    lastFiveGames: 7,
    homeAdvantage: 7.2,
    awayDisadvantage: 6.2,
    averageGoalsFor: 1.4,
    averageGoalsAgainst: 1.5
  },
  
  // Premier League Teams
  {
    id: 'man-city',
    name: 'Manchester City',
    league: 'Premier Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/b/ba/Manchester_City.svg',
    form: 9.0,
    lastFiveGames: 13,
    homeAdvantage: 9.2,
    awayDisadvantage: 8.0,
    averageGoalsFor: 2.6,
    averageGoalsAgainst: 0.7
  },
  {
    id: 'liverpool',
    name: 'Liverpool',
    league: 'Premier Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/3/3f/150px-Liverpool_FC_logo.png',
    form: 8.8,
    lastFiveGames: 13,
    homeAdvantage: 9.0,
    awayDisadvantage: 8.2,
    averageGoalsFor: 2.5,
    averageGoalsAgainst: 0.8
  },
  {
    id: 'arsenal',
    name: 'Arsenal',
    league: 'Premier Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/9/92/Arsenal_Football_Club.png',
    form: 8.5,
    lastFiveGames: 12,
    homeAdvantage: 8.8,
    awayDisadvantage: 7.8,
    averageGoalsFor: 2.3,
    averageGoalsAgainst: 0.9
  },
  {
    id: 'chelsea',
    name: 'Chelsea',
    league: 'Premier Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/1/13/Chelsea_FC.png',
    form: 7.8,
    lastFiveGames: 10,
    homeAdvantage: 8.5,
    awayDisadvantage: 7.5,
    averageGoalsFor: 2.0,
    averageGoalsAgainst: 1.1
  },
  {
    id: 'man-utd',
    name: 'Manchester United',
    league: 'Premier Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/d/d8/Manchester_United_FC_logo.png',
    form: 7.5,
    lastFiveGames: 9,
    homeAdvantage: 8.3,
    awayDisadvantage: 7.3,
    averageGoalsFor: 1.9,
    averageGoalsAgainst: 1.2
  },
  {
    id: 'tottenham',
    name: 'Tottenham',
    league: 'Premier Lig',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/7/7d/Tottenham_Hotspur.png',
    form: 7.8,
    lastFiveGames: 11,
    homeAdvantage: 8.0,
    awayDisadvantage: 7.0,
    averageGoalsFor: 2.1,
    averageGoalsAgainst: 1.0
  },
  
  // La Liga Teams
  {
    id: 'real-madrid',
    name: 'Real Madrid',
    league: 'La Liga',
    logo: 'https://upload.wikimedia.org/wikipedia/en/5/56/Real_Madrid_CF.svg',
    form: 9.2,
    lastFiveGames: 15,
    homeAdvantage: 9.3,
    awayDisadvantage: 8.5,
    averageGoalsFor: 2.3,
    averageGoalsAgainst: 0.6
  },
  {
    id: 'barcelona',
    name: 'Barcelona',
    league: 'La Liga',
    logo: 'https://upload.wikimedia.org/wikipedia/en/4/47/FC_Barcelona_%28crest%29.svg',
    form: 8.5,
    lastFiveGames: 12,
    homeAdvantage: 9.0,
    awayDisadvantage: 8.0,
    averageGoalsFor: 2.4,
    averageGoalsAgainst: 0.9
  },
  {
    id: 'atletico',
    name: 'Atlético Madrid',
    league: 'La Liga',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/9/90/Atl%C3%A9tico_Madrid_logo.png',
    form: 8.0,
    lastFiveGames: 11,
    homeAdvantage: 8.5,
    awayDisadvantage: 7.5,
    averageGoalsFor: 1.8,
    averageGoalsAgainst: 0.8
  },
  {
    id: 'sevilla',
    name: 'Sevilla',
    league: 'La Liga',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/3/3c/Sevilla_FC_logo.png',
    form: 7.5,
    lastFiveGames: 9,
    homeAdvantage: 8.0,
    awayDisadvantage: 7.0,
    averageGoalsFor: 1.7,
    averageGoalsAgainst: 1.1
  },
  
  // Bundesliga Teams
  {
    id: 'bayern',
    name: 'Bayern Münih',
    league: 'Bundesliga',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/1/1b/FC_Bayern_M%C3%BCnchen_logo_%282017%29.svg',
    form: 9.0,
    lastFiveGames: 13,
    homeAdvantage: 9.1,
    awayDisadvantage: 8.3,
    averageGoalsFor: 2.8,
    averageGoalsAgainst: 0.8
  },
  {
    id: 'dortmund',
    name: 'Borussia Dortmund',
    league: 'Bundesliga',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/6/67/Borussia_Dortmund_logo.svg',
    form: 8.0,
    lastFiveGames: 11,
    homeAdvantage: 8.7,
    awayDisadvantage: 7.4,
    averageGoalsFor: 2.2,
    averageGoalsAgainst: 1.1
  },
  {
    id: 'leipzig',
    name: 'RB Leipzig',
    league: 'Bundesliga',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/0/04/RB_Leipzig_2014_logo.png',
    form: 7.8,
    lastFiveGames: 10,
    homeAdvantage: 8.2,
    awayDisadvantage: 7.2,
    averageGoalsFor: 2.0,
    averageGoalsAgainst: 1.2
  },
  {
    id: 'leverkusen',
    name: 'Bayer Leverkusen',
    league: 'Bundesliga',
    logo: 'https://upload.wikimedia.org/wikipedia/tr/5/59/Bayer_04_Leverkusen.png',
    form: 7.5,
    lastFiveGames: 9,
    homeAdvantage: 8.0,
    awayDisadvantage: 7.0,
    averageGoalsFor: 1.9,
    averageGoalsAgainst: 1.3
  }
];

export const mockedMatches: Match[] = [
  {
    id: 'match-1',
    homeTeam: mockedTeams.find(t => t.id === 'gs')!,
    awayTeam: mockedTeams.find(t => t.id === 'fb')!,
    date: '2025-04-20T19:00:00',
    stadium: 'Ali Sami Yen',
    league: 'Super Lig',
    status: 'upcoming'
  },
  {
    id: 'match-2',
    homeTeam: mockedTeams.find(t => t.id === 'bjk')!,
    awayTeam: mockedTeams.find(t => t.id === 'ts')!,
    date: '2025-04-19T16:00:00',
    stadium: 'Vodafone Park',
    league: 'Super Lig',
    status: 'upcoming'
  },
  {
    id: 'match-3',
    homeTeam: mockedTeams.find(t => t.id === 'man-city')!,
    awayTeam: mockedTeams.find(t => t.id === 'liverpool')!,
    date: '2025-04-18T20:00:00',
    stadium: 'Etihad Stadium',
    league: 'Premier Lig',
    status: 'upcoming'
  },
  {
    id: 'match-4',
    homeTeam: mockedTeams.find(t => t.id === 'real-madrid')!,
    awayTeam: mockedTeams.find(t => t.id === 'barcelona')!,
    date: '2025-04-25T21:00:00',
    stadium: 'Santiago Bernabéu',
    league: 'La Liga',
    status: 'upcoming'
  },
  {
    id: 'match-5',
    homeTeam: mockedTeams.find(t => t.id === 'bayern')!,
    awayTeam: mockedTeams.find(t => t.id === 'dortmund')!,
    date: '2025-04-26T19:30:00',
    stadium: 'Allianz Arena',
    league: 'Bundesliga',
    status: 'upcoming'
  },
  {
    id: 'match-6',
    homeTeam: mockedTeams.find(t => t.id === 'arsenal')!,
    awayTeam: mockedTeams.find(t => t.id === 'chelsea')!,
    date: '2025-04-27T17:30:00',
    stadium: 'Emirates Stadium',
    league: 'Premier Lig',
    status: 'upcoming'
  },
  {
    id: 'match-7',
    homeTeam: mockedTeams.find(t => t.id === 'atletico')!,
    awayTeam: mockedTeams.find(t => t.id === 'sevilla')!,
    date: '2025-04-28T20:00:00',
    stadium: 'Metropolitano',
    league: 'La Liga',
    status: 'upcoming'
  },
  {
    id: 'match-8',
    homeTeam: mockedTeams.find(t => t.id === 'leipzig')!,
    awayTeam: mockedTeams.find(t => t.id === 'leverkusen')!,
    date: '2025-04-29T19:30:00',
    stadium: 'Red Bull Arena',
    league: 'Bundesliga',
    status: 'upcoming'
  }
];

export const mockedComments: Comment[] = [
  {
    id: 'comment-1',
    matchId: 'match-1',
    userId: 'user-1',
    userName: 'Ali Can',
    text: 'Bu derbinin favorisi kesinlikle Galatasaray! Evlerinde çok güçlüler.',
    created: '2025-04-18T10:30:00',
    likes: 24
  },
  {
    id: 'comment-2',
    matchId: 'match-1',
    userId: 'user-2',
    userName: 'Mehmet Yılmaz',
    text: 'Fenerbahçe bu sene dış sahada da çok iyi oynuyor, sürpriz yapabilirler.',
    created: '2025-04-18T11:15:00',
    likes: 18
  },
  {
    id: 'comment-3',
    matchId: 'match-1',
    userId: 'user-3',
    userName: 'Zeynep Kaya',
    text: 'Beraberlik bence en mantıklı sonuç olur, iki takım da formda.',
    created: '2025-04-18T12:05:00',
    likes: 9
  },
  {
    id: 'comment-4',
    matchId: 'match-2',
    userId: 'user-4',
    userName: 'Burak Demir',
    text: 'Beşiktaş bu maçı alır, son haftalarda çok iyiler.',
    created: '2025-04-17T15:45:00',
    likes: 12
  },
  {
    id: 'comment-5',
    matchId: 'match-3',
    userId: 'user-5',
    userName: 'Emre Şahin',
    text: 'Premier Lig\'in en büyük derbisinde Manchester City\'nin üstünlüğünü göreceğiz.',
    created: '2025-04-16T09:20:00',
    likes: 31
  }
];